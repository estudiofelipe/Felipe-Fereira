import { useState } from 'react';
import { Header } from '@/app/components/Header';
import { Banner } from '@/app/components/Banner';
import { ProjectGrid } from '@/app/components/ProjectGrid';
import { ServicesSection } from '@/app/components/ServicesSection';
import { AboutSection } from '@/app/components/AboutSection';
import { CTASection } from '@/app/components/CTASection';
import { Footer } from '@/app/components/Footer';
import { ProcessModal } from '@/app/components/ProcessModal';
import { ContactModal } from '@/app/components/ContactModal';

function App() {
  const [isProcessModalOpen, setIsProcessModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Banner onOpenModal={() => setIsProcessModalOpen(true)} />
      <ProjectGrid />
      <ServicesSection />
      <AboutSection />
      <CTASection onOpenContact={() => setIsContactModalOpen(true)} />
      <Footer />
      <ProcessModal 
        isOpen={isProcessModalOpen} 
        onClose={() => setIsProcessModalOpen(false)} 
      />
      <ContactModal 
        isOpen={isContactModalOpen} 
        onClose={() => setIsContactModalOpen(false)} 
      />
    </div>
  );
}

export default App;