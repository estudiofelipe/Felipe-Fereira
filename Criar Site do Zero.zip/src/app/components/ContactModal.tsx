import { X } from 'lucide-react';
import { useEffect, useState } from 'react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ContactModal({ isOpen, onClose }: ContactModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aqui você pode adicionar lógica de envio do formulário
    const mailtoLink = `mailto:ola@estudiofelipe.com.br?subject=Solicitação de Projeto - ${formData.name}&body=Nome: ${formData.name}%0D%0AEmail: ${formData.email}%0D%0ATelefone: ${formData.phone}%0D%0AEmpresa: ${formData.company}%0D%0A%0D%0AMensagem:%0D%0A${formData.message}`;
    window.location.href = mailtoLink;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 animate-fadeIn"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto relative animate-slideUp">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition-colors z-10"
          aria-label="Fechar"
        >
          <X size={28} />
        </button>

        {/* Content */}
        <div className="p-8 lg:p-12">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
            {/* Left Column - Text */}
            <div className="flex flex-col justify-center">
              <h2 className="font-black text-3xl lg:text-4xl mb-4 leading-tight">
                Vamos conhecer seus desafios.
              </h2>
              <p className="text-gray-700 font-medium text-base lg:text-lg leading-relaxed">
                Preencha a solicitação para que possamos agendar um horário e conversarmos sobre seu projeto. Se preferir, nos envie um e-mail para{' '}
                <a
                  href="mailto:ola@estudiofelipe.com.br"
                  className="text-black underline hover:no-underline font-black"
                >
                  ola@estudiofelipe.com.br
                </a>
              </p>
            </div>

            {/* Right Column - Form */}
            <div>
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Nome */}
                <div>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-black focus:outline-none transition-colors font-medium"
                    placeholder="Nome completo *"
                  />
                </div>

                {/* Email */}
                <div>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-black focus:outline-none transition-colors font-medium"
                    placeholder="E-mail *"
                  />
                </div>

                {/* Telefone */}
                <div>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-black focus:outline-none transition-colors font-medium"
                    placeholder="Telefone *"
                  />
                </div>

                {/* Empresa */}
                <div>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-black focus:outline-none transition-colors font-medium"
                    placeholder="Empresa"
                  />
                </div>

                {/* Mensagem */}
                <div>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-black focus:outline-none transition-colors font-medium resize-none"
                    placeholder="Fale sobre seu projeto *"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-black text-white px-8 py-3.5 rounded-full hover:bg-gray-800 transition-all duration-300 font-black text-base"
                >
                  Enviar Solicitação
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}