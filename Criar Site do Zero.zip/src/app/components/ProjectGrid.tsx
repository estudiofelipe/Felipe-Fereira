import { useState } from 'react';
import { motion } from 'motion/react';
import unityDefault from 'figma:asset/c1144ba45c9a7ca482c323f0a21b76e087dd8b33.png';
import unityHover from 'figma:asset/8840f052954f11fa652e17d116a60cba01ca81ab.png';
import nossoVerdeDefault from 'figma:asset/410d67e274892f564a094176bfd1819a1bb10e31.png';
import nossoVerdeHover from 'figma:asset/241b9d5c2e13bf1b391f1809f62c73143e2851e1.png';
import danieleDefault from 'figma:asset/f91ec7e2d53e2b58ebe15ba1a24205280a53a4a8.png';
import danieleHover from 'figma:asset/06411adf5705409b576ca8d921aa69058c137306.png';
import cassioMeloDefault from 'figma:asset/13bb71602b0dd3f9998aa6751a349a2421256765.png';
import cassioMeloHover from 'figma:asset/8995873fe29261f382657214bebbcea76222b1fc.png';
import trevisaniDefault from 'figma:asset/1ffb6f377af09a628ff5f5acf79ebe82c901ccf2.png';
import trevisaniHover from 'figma:asset/f65b12067d135798a6514bec27045ee8140f6121.png';
import vivaRioDefault from 'figma:asset/90d521d55cd36e92ef0404dee7287d832b956243.png';
import vivaRioHover from 'figma:asset/9b21f7eece7eb58cf252537e5f84e28542b5856a.png';
import tudimDefault from 'figma:asset/58b1dedaad770473cac7bac0dd142f5f6425c542.png';
import tudimHover from 'figma:asset/c70f5ecf689a6f62cbc2dc8674b84da1cdaef43a.png';
import camikidsDefault from 'figma:asset/965cc9565af7677b6fcf55e6286726e5e70bcec0.png';
import camikidsHover from 'figma:asset/0f9416369247b989fbe73dadae6385c0bcc9ac37.png';
import correioDefault from 'figma:asset/f24865cc880da38088681d611028322eef1271e2.png';
import correioHover from 'figma:asset/ded5f10b55d49ab97fd7a949d7bdd6e26d9c3366.png';

interface Project {
  id: number;
  imageDefault: string;
  imageHover: string;
  title: string;
}

export function ProjectGrid() {
  const projects: Project[] = [
    {
      id: 1,
      imageDefault: unityDefault,
      imageHover: unityHover,
      title: 'Unity Perícias'
    },
    {
      id: 2,
      imageDefault: nossoVerdeDefault,
      imageHover: nossoVerdeHover,
      title: 'Nosso Verde'
    },
    {
      id: 3,
      imageDefault: danieleDefault,
      imageHover: danieleHover,
      title: 'Daniele Santos'
    },
    {
      id: 4,
      imageDefault: cassioMeloDefault,
      imageHover: cassioMeloHover,
      title: 'Cassio Melo'
    },
    {
      id: 5,
      imageDefault: trevisaniDefault,
      imageHover: trevisaniHover,
      title: 'Trevisani'
    },
    {
      id: 6,
      imageDefault: vivaRioDefault,
      imageHover: vivaRioHover,
      title: 'Viva o Rio'
    },
    {
      id: 7,
      imageDefault: tudimDefault,
      imageHover: tudimHover,
      title: 'Tudim'
    },
    {
      id: 8,
      imageDefault: camikidsDefault,
      imageHover: camikidsHover,
      title: 'Camikids'
    },
    {
      id: 9,
      imageDefault: correioDefault,
      imageHover: correioHover,
      title: 'Correio'
    }
  ];

  return (
    <section className="w-full px-6 py-6">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, index }: { project: Project, index: number }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className="relative aspect-[4/3] rounded-2xl overflow-hidden cursor-pointer group"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{
        duration: 0.6,
        delay: index * 0.1,
        ease: [0.21, 0.47, 0.32, 0.98]
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Imagem padrão */}
      <img
        src={project.imageDefault}
        alt={project.title}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
          isHovered ? 'opacity-0' : 'opacity-100'
        }`}
      />
      
      {/* Imagem hover */}
      <img
        src={project.imageHover}
        alt={`${project.title} hover`}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      />
    </motion.div>
  );
}