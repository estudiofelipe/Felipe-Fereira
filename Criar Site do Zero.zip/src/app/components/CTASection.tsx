import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface CTASectionProps {
  onOpenContact: () => void;
}

export function CTASection({ onOpenContact }: CTASectionProps) {
  return (
    <section id="contato" className="py-8">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="grid md:grid-cols-2 gap-4 rounded-2xl overflow-hidden">
          {/* Content */}
          <div className="bg-black text-white flex items-center justify-center p-8 lg:p-16 rounded-2xl md:rounded-l-2xl md:rounded-r-none">
            <div className="max-w-2xl">
              <h2 className="text-white mb-4 leading-tight font-black text-3xl lg:text-4xl">
                Precisa de um projeto?
              </h2>
              <p className="text-white/80 mb-6 text-base lg:text-lg leading-relaxed font-medium">
                Agende uma conversa com nossa equipe. Estamos dispostos a entender sobre sua marca para oferecer uma solução eficiente e criativa.
              </p>
              <button
                onClick={onOpenContact}
                className="inline-block bg-transparent border-2 border-white text-white px-6 py-2.5 rounded-full hover:bg-white hover:text-black transition-all duration-300 font-black text-sm"
              >
                Agendar Call
              </button>
            </div>
          </div>

          {/* Image */}
          <div className="aspect-[4/3] md:aspect-auto">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1763191213523-1489179a1088?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHdvcmtzcGFjZSUyMGRlc2lnbnxlbnwxfHx8fDE3Njg1ODY1MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Design Criativo"
              className="w-full h-full object-cover rounded-2xl md:rounded-l-none md:rounded-r-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}