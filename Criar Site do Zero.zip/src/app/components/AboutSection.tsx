import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

export function AboutSection() {
  return (
    <section id="sobre" className="py-8">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        <div className="grid md:grid-cols-2 gap-4 rounded-2xl overflow-hidden">
          {/* Image */}
          <div className="aspect-[4/3] md:aspect-auto">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1759157403273-2423c0f5718b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYnJhbmRpbmclMjBkZXNpZ258ZW58MXx8fHwxNzY4NjIwMzc4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Branding e Design"
              className="w-full h-full object-cover rounded-2xl md:rounded-l-2xl md:rounded-r-none"
            />
          </div>

          {/* Content */}
          <div className="bg-gray-100 flex items-center justify-center p-8 lg:p-16 rounded-2xl md:rounded-l-none md:rounded-r-2xl">
            <div className="max-w-2xl">
              <h2 className="mb-4 leading-tight font-black text-3xl lg:text-4xl">
                Criamos para marcas que buscam crescer e inovar.
              </h2>
              <p className="text-gray-700 text-base lg:text-lg leading-relaxed font-medium">
                Sabemos que empresas carregam qualidades e entregas relevantes que podem ser trabalhadas na percepção visual da sua marca.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
