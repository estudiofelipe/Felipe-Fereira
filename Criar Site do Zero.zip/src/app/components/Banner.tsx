import { useState, useEffect, useRef } from 'react';
import { ProcessModal } from '@/app/components/ProcessModal';
import bannerImage1 from 'figma:asset/6cfa9d4c634cfb43f8086bd52c7ee27cdfa86ca6.png';
import bannerImage2 from 'figma:asset/d2a5e150f58386c0a992f00eb4bcd34c0fd2dcf7.png';
import bannerImage3 from 'figma:asset/f7ed6b2cb83c0579e04bae81e687d68ae67def27.png';
import bannerImage4 from 'figma:asset/0fc6c74ebc9c655c17461c4065b7c1d6ab2623af.png';

export function Banner() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const bannerRef = useRef<HTMLDivElement>(null);

  // Array de imagens para desktop
  const images = [
    bannerImage1,
    bannerImage2,
    bannerImage3,
    bannerImage4
  ];

  // Array de cores para mobile - independente das imagens do desktop
  const colors = [
    "#E8C547",  // Amarelo
    "#8B7BC8",  // Roxo
    "#FFD4D4",  // Rosa
    "#D3D3D3",  // Cinza
    "#00A8FF"   // Azul
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 7000);

    return () => clearInterval(interval);
  }, [images.length]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <section className="w-full px-6 py-6">
        <div 
          className="max-w-5xl mx-auto rounded-3xl p-8 md:p-12 lg:p-16 overflow-hidden relative transition-colors duration-1000 lg:bg-[#8B7BC8]"
          style={{ backgroundColor: isMobile ? colors[currentIndex % colors.length] : undefined }}
          ref={bannerRef}
        >
          {/* Imagens de fundo para Desktop */}
          <div className="hidden lg:block absolute inset-0 rounded-3xl overflow-hidden">
            {images.map((img, index) => (
              <img 
                key={index}
                src={img}
                alt={`Banner image ${index + 1}`}
                className={`w-full h-full object-cover absolute inset-0 transition-opacity duration-1000 ${
                  index === currentIndex ? 'opacity-100' : 'opacity-0'
                }`}
              />
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8 items-center relative z-10">
            {/* Coluna Esquerda - Texto */}
            <div className="max-w-lg">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-black mb-4 leading-[1.1]">
                Design fala quando palavras não são suficientes.
              </h1>
              <p className="text-black/80 mb-8 text-sm md:text-base leading-[1.4] font-bold">
                As marcas que mais crescem são aquelas que investem em design, especialmente na identidade visual.
              </p>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="px-6 py-3 border-2 border-black text-black font-bold rounded-full hover:bg-black hover:text-white transition-all duration-300"
              >
                Como trabalhamos?
              </button>
            </div>

            {/* Coluna Direita - Espaço vazio para layout */}
            <div className="hidden lg:block"></div>
          </div>
        </div>
      </section>

      <ProcessModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}