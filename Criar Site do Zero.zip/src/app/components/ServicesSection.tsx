import { useEffect, useRef, useState } from 'react';
import { Palette, Sparkles, Layout, Package } from 'lucide-react';

const services = [
  {
    id: 1,
    title: 'Identidade Visual',
    description: 'Criação completa de identidade visual que traduz a essência da sua marca.',
    icon: Palette,
  },
  {
    id: 2,
    title: 'Branding',
    description: 'Estratégia e desenvolvimento de marca para destacar seu negócio no mercado.',
    icon: Sparkles,
  },
  {
    id: 3,
    title: 'Design de Logo',
    description: 'Logos únicos e memoráveis que representam a personalidade da sua empresa.',
    icon: Layout,
  },
  {
    id: 4,
    title: 'Material Gráfico',
    description: 'Cartões de visita, papelaria e todo material impresso e digital necessário.',
    icon: Package,
  },
];

export function ServicesSection() {
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = cardRefs.current.indexOf(entry.target as HTMLDivElement);
            if (index !== -1 && !visibleCards.includes(index)) {
              setTimeout(() => {
                setVisibleCards((prev) => [...prev, index]);
              }, index * 150);
            }
          }
        });
      },
      { threshold: 0.2, rootMargin: '0px' }
    );

    cardRefs.current.forEach((card) => {
      if (card) observer.observe(card);
    });

    return () => observer.disconnect();
  }, [visibleCards]);

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-12">
        {/* Section Header */}
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="font-black text-4xl lg:text-5xl mb-4">Serviços</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto font-medium">
            Soluções criativas e estratégicas para elevar sua marca
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                ref={(el) => (cardRefs.current[index] = el)}
                className={`group bg-white border-2 border-black rounded-2xl p-8 hover:bg-black cursor-pointer transition-all duration-700 ease-out ${
                  visibleCards.includes(index)
                    ? 'opacity-100 scale-100'
                    : 'opacity-0 scale-75'
                }`}
              >
                <div className="mb-6">
                  <div className="w-14 h-14 rounded-full bg-black group-hover:bg-white transition-colors duration-500 flex items-center justify-center">
                    <Icon className="w-7 h-7 text-white group-hover:text-black transition-colors duration-500" />
                  </div>
                </div>
                <h3 className="font-black text-xl mb-3 text-black group-hover:text-white transition-colors duration-500">
                  {service.title}
                </h3>
                <p className="text-gray-600 group-hover:text-gray-300 transition-colors duration-500 font-medium">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
