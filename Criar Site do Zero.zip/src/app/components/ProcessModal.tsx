import { X, Search, Target, Lightbulb, Presentation, PackageCheck } from 'lucide-react';
import { useEffect } from 'react';

interface ProcessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProcessModal({ isOpen, onClose }: ProcessModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 animate-fadeIn"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto relative animate-slideUp">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 lg:p-10 flex items-center justify-between rounded-t-3xl z-10">
          <h2 className="font-black text-3xl lg:text-4xl">Como trabalhamos?</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Fechar"
          >
            <X size={28} />
          </button>
        </div>

        {/* Intro Text */}
        <div className="px-6 lg:px-10 pt-10 pb-6">
          <h3 className="font-black text-3xl lg:text-4xl mb-6">
            Ouvir, criar e aplicar.
          </h3>
          <p className="text-gray-700 font-medium text-lg lg:text-xl max-w-3xl">
            Nosso processo começa sempre com uma boa conversa para entender, de fato, a essência da sua marca. Portanto, cada projeto vai contar com uma abordagem única. Isso é design! Mas, também é arte. Conheça as 5 etapas do nosso método:
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-0">
          {/* Step 1 - Orbe */}
          <section className="grid md:grid-cols-2 gap-8 lg:gap-12 px-6 lg:px-10 py-12 lg:py-16 bg-gray-50">
            <div className="flex items-center justify-center">
              <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-black flex items-center justify-center">
                <Search className="w-16 h-16 lg:w-20 lg:h-20 text-white" />
              </div>
            </div>
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black text-white font-black text-sm px-3 py-1 rounded-full">01</span>
                <h3 className="font-black text-2xl lg:text-3xl">Orbe</h3>
              </div>
              <p className="text-gray-700 font-medium text-base lg:text-lg mb-4">
                Um movimento 360° para entender profundamente como o design vai ajudar a posicionar essa marca no mercado.
              </p>
              <p className="text-gray-600 font-medium text-base">
                Provocações que vão nos ajudar entender o que a marca faz, como ela faz e por que ela faz. Entender quem é o público, quem são os concorrentes e analisar como ela pode se diferenciar no mercado.
              </p>
            </div>
          </section>

          {/* Step 2 - Eixo */}
          <section className="grid md:grid-cols-2 gap-8 lg:gap-12 px-6 lg:px-10 py-12 lg:py-16 bg-white">
            <div className="flex flex-col justify-center md:order-1">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black text-white font-black text-sm px-3 py-1 rounded-full">02</span>
                <h3 className="font-black text-2xl lg:text-3xl">Eixo</h3>
              </div>
              <p className="text-gray-700 font-medium text-base lg:text-lg mb-4">
                Centralizar, equilibrar e identificar a direção exata da nossa jornada.
              </p>
              <p className="text-gray-600 font-medium text-base">
                Um relatório de tudo o que foi analisado e descoberto até aqui. Também, faremos juntos uma atividade para entendermos qual direção visual seguir, alinhando expectativas e direcionando nossos esforços para trabalhar de forma inteligente.
              </p>
            </div>
            <div className="flex items-center justify-center md:order-2">
              <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-black flex items-center justify-center">
                <Target className="w-16 h-16 lg:w-20 lg:h-20 text-white" />
              </div>
            </div>
          </section>

          {/* Step 3 - Neo */}
          <section className="grid md:grid-cols-2 gap-8 lg:gap-12 px-6 lg:px-10 py-12 lg:py-16 bg-gray-50">
            <div className="flex items-center justify-center">
              <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-black flex items-center justify-center">
                <Lightbulb className="w-16 h-16 lg:w-20 lg:h-20 text-white" />
              </div>
            </div>
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black text-white font-black text-sm px-3 py-1 rounded-full">03</span>
                <h3 className="font-black text-2xl lg:text-3xl">Neo</h3>
              </div>
              <p className="text-gray-700 font-medium text-base lg:text-lg mb-4">
                Um fluxo de criação concretizando soluções eficazes das formas, cores, tipografia e elementos de apoio.
              </p>
              <p className="text-gray-600 font-medium text-base">
                É hora de iniciarmos a materialização das estratégias feitas nas etapas anteriores. Por meio de rascunhos, buscamos gerar um conjunto de ideias seguindo as diretrizes da marca, logo após, filtramos as melhores e lapidamos até alcançar o formato ideal.
              </p>
            </div>
          </section>

          {/* Step 4 - Surge */}
          <section className="grid md:grid-cols-2 gap-8 lg:gap-12 px-6 lg:px-10 py-12 lg:py-16 bg-white">
            <div className="flex flex-col justify-center md:order-1">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black text-white font-black text-sm px-3 py-1 rounded-full">04</span>
                <h3 className="font-black text-2xl lg:text-3xl">Surge</h3>
              </div>
              <p className="text-gray-700 font-medium text-base lg:text-lg mb-4">
                O grande momento de apresentar o resultado com as devidas aplicações da marca e o processo criativo.
              </p>
              <p className="text-gray-600 font-medium text-base">
                Com a participação de todos os sócios, vamos recapitular como foi o desenvolvimento do projeto até chegar à ideia central e compreender as funcionalidades e vantagens do novo sistema visual.
              </p>
            </div>
            <div className="flex items-center justify-center md:order-2">
              <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-black flex items-center justify-center">
                <Presentation className="w-16 h-16 lg:w-20 lg:h-20 text-white" />
              </div>
            </div>
          </section>

          {/* Step 5 - Sina */}
          <section className="grid md:grid-cols-2 gap-8 lg:gap-12 px-6 lg:px-10 py-12 lg:py-16 bg-gray-50">
            <div className="flex items-center justify-center">
              <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-black flex items-center justify-center">
                <PackageCheck className="w-16 h-16 lg:w-20 lg:h-20 text-white" />
              </div>
            </div>
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-3">
                <span className="bg-black text-white font-black text-sm px-3 py-1 rounded-full">05</span>
                <h3 className="font-black text-2xl lg:text-3xl">Sina</h3>
              </div>
              <p className="text-gray-700 font-medium text-base lg:text-lg mb-4">
                Finalização e entrega dos arquivos que incluem logotipo e suas versões, fonte, elementos gráficos e manual.
              </p>
              <p className="text-gray-600 font-medium text-base">
                Preparamos um pacote com todos os entregáveis com manual, que é um documento importante para a equipe interna de design e parceiros, trazendo informações essenciais para a correta reprodução da marca, protegendo assim suas características fundamentais.
              </p>
            </div>
          </section>
        </div>

        {/* CTA Final */}
        <div className="bg-black text-white px-6 lg:px-10 py-12 lg:py-16 rounded-b-3xl text-center">
          <h3 className="font-black text-2xl lg:text-3xl mb-4">
            Pronto para começar?
          </h3>
          <p className="text-white/80 font-medium mb-8 text-base lg:text-lg max-w-2xl mx-auto">
            Agende uma conversa gratuita e vamos transformar sua marca juntos.
          </p>
          <a
            href="mailto:ola@estudiofelipe.com.br"
            className="inline-block bg-white text-black px-8 py-3 rounded-full hover:bg-gray-200 transition-all duration-300 font-black"
          >
            Entrar em contato
          </a>
        </div>
      </div>
    </div>
  );
}