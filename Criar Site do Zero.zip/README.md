
  # Criar Site do Zero

  This is a code bundle for Criar Site do Zero. The original project is available at https://www.figma.com/design/gmtDv1o2UwEhVqLRcfH2mp/Criar-Site-do-Zero.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  